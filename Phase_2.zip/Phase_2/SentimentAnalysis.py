import re
import nltk
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder, label_binarize
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix, roc_curve, auc, precision_recall_curve
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
import matplotlib.pyplot as plt
import seaborn as sns
import lime
import lime.lime_tabular
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np

# Ensure necessary NLTK resources are downloaded
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')

# Initialize stop words and lemmatizer
stop_words = set(nltk.corpus.stopwords.words('english'))
lemmatizer = nltk.stem.WordNetLemmatizer()

# Define text preprocessing function
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'\W', ' ', text)
    text = re.sub(r'\d', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    tokens = nltk.word_tokenize(text)
    tokens = [lemmatizer.lemmatize(word) for word in tokens if word not in stop_words]
    return ' '.join(tokens)

print("Starting script execution...")

# Load the dataset
file_path = '/Users/sairishi/Desktop/Data-Science-Project-Series/Phase_2/test.csv'
df = pd.read_csv(file_path, encoding='ISO-8859-1')
print("Dataset loaded successfully.")

# Display basic information about the dataframe
print(df.head())
print(df.info())
print(df['sentiment'].value_counts())

# Drop rows with NaN values in the 'text' column
df = df.dropna(subset=['text'])
print("NaN values dropped from 'text' column.")

# Ensure the 'text' column contains only string values
df['text'] = df['text'].astype(str)
print("'text' column converted to string values.")

# Apply the preprocessing function to the text column
df['cleaned_text'] = df['text'].apply(preprocess_text)
print("Text preprocessing applied.")

# Display the first few rows of the dataframe to verify preprocessing
print(df[['text', 'cleaned_text']].head())

# Perform Exploratory Data Analysis (EDA)
print("Starting EDA...")
try:
    print("Creating count plot...")
    plt.figure(figsize=(8, 6))
    sns.set(style="whitegrid")
    sns.countplot(x='sentiment', data=df, palette='viridis', hue='sentiment', dodge=False, legend=False)
    plt.title('Distribution of Sentiment Labels')
    plt.xlabel('Sentiment')
    plt.ylabel('Count')
    plt.show()
    print("Count plot displayed.")
    
    print("Creating pie chart...")
    plt.figure(figsize=(8, 8))
    df['sentiment'].value_counts().plot.pie(autopct='%1.1f%%', startangle=140, colors=['#1f77b4', '#ff7f0e', '#2ca02c'])
    plt.title('Pie Chart of Sentiment Labels')
    plt.ylabel('')  # Hide y-label
    plt.show()
    print("Pie chart displayed.")
except Exception as e:
    print(f"An error occurred during EDA: {e}")

# Initialize the TF-IDF Vectorizer
tfidf_vectorizer = TfidfVectorizer(max_features=5000)
print("TF-IDF Vectorizer initialized.")

# Fit and transform the cleaned text data
X = tfidf_vectorizer.fit_transform(df['cleaned_text'])
print("TF-IDF Vectorizer fitted and transformed.")

# Convert the transformed data into an array for further use
X_array = X.toarray()
print("TF-IDF matrix converted to array.")

# Display the shape of the resulting TF-IDF matrix
print(f"Shape of TF-IDF matrix: {X_array.shape}")

# Optional: Display feature names (words) and the first row of the TF-IDF matrix
feature_names = tfidf_vectorizer.get_feature_names_out()
print(f"Feature names (first 10): {feature_names[:10]}")
print(f"First row of TF-IDF matrix: {X_array[0]}")

# Encode the sentiment labels
label_encoder = LabelEncoder()
df['sentiment_encoded'] = label_encoder.fit_transform(df['sentiment'])
print("Sentiment labels encoded.")

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_array, df['sentiment_encoded'], test_size=0.2, random_state=42)
print("Data split into training and testing sets.")

# Reduce the dataset size for debugging purposes
X_train_small = X_train[:1000]
y_train_small = y_train[:1000]
X_test_small = X_test[:200]
y_test_small = y_test[:200]
print("Dataset size reduced for debugging purposes.")

# Naive Bayes Model
print("Training Naive Bayes model...")
nb_model = MultinomialNB()
nb_model.fit(X_train_small, y_train_small)
nb_pred = nb_model.predict(X_test_small)
print("Naive Bayes model trained.")
print("Naive Bayes Model")
print(f"Accuracy: {accuracy_score(y_test_small, nb_pred):.4f}")
print(f"Precision: {precision_score(y_test_small, nb_pred, average='weighted'):.4f}")
print(f"Recall: {recall_score(y_test_small, nb_pred, average='weighted'):.4f}")
print(f"F1 Score: {f1_score(y_test_small, nb_pred, average='weighted'):.4f}")
print(classification_report(y_test_small, nb_pred))
print("-" * 50)

# Add SVM Model with detailed logging
print("Training SVM model...")
try:
    svm_model = SVC(kernel='linear', probability=True)
    svm_model.fit(X_train_small, y_train_small)
    print("SVM model trained successfully.")
    
    svm_pred = svm_model.predict(X_test_small)
    print("SVM predictions made successfully.")
    
    print("Support Vector Machine Model")
    print(f"Accuracy: {accuracy_score(y_test_small, svm_pred):.4f}")
    print(f"Precision: {precision_score(y_test_small, svm_pred, average='weighted'):.4f}")
    print(f"Recall: {recall_score(y_test_small, svm_pred, average='weighted'):.4f}")
    print(f"F1 Score: {f1_score(y_test_small, svm_pred, average='weighted'):.4f}")
    print(classification_report(y_test_small, svm_pred))
    print("-" * 50)
except Exception as e:
    print(f"An error occurred during SVM training: {e}")


# Define the LSTM model
class LSTMClassifier(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(LSTMClassifier, self).__init__()
        self.hidden_dim = hidden_dim
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        h0 = torch.zeros(1, x.size(0), self.hidden_dim).to(x.device)
        c0 = torch.zeros(1, x.size(0), self.hidden_dim).to(x.device)
        out, _ = self.lstm(x.unsqueeze(1), (h0, c0))  # Add .unsqueeze(1) to add a sequence dimension
        out = self.fc(out[:, -1, :])
        return out

input_dim = X_train_small.shape[1]
hidden_dim = 128
output_dim = len(np.unique(y_train_small))

model = LSTMClassifier(input_dim, hidden_dim, output_dim)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Convert to PyTorch tensors for LSTM model
X_train_tensor = torch.tensor(X_train_small, dtype=torch.float32)
X_test_tensor = torch.tensor(X_test_small, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train_small.to_numpy(), dtype=torch.long)  # Convert to numpy array
y_test_tensor = torch.tensor(y_test_small.to_numpy(), dtype=torch.long)    # Convert to numpy array

# Create custom dataset
class TextDataset(Dataset):
    def __init__(self, X, y):
        self.X = X
        self.y = y

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

train_dataset = TextDataset(X_train_tensor, y_train_tensor)
test_dataset = TextDataset(X_test_tensor, y_test_tensor)

# Create data loaders
train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)

# Train the LSTM model
print("Training LSTM model...")
num_epochs = 5
model.train()
for epoch in range(num_epochs):
    for texts, labels in train_loader:
        outputs = model(texts)
        loss = criterion(outputs, labels)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}')

# Evaluate the LSTM model
print("Evaluating LSTM model...")
model.eval()
y_pred, y_true = [], []
with torch.no_grad():
    for texts, labels in test_loader:
        outputs = model(texts)
        _, predicted = torch.max(outputs, 1)
        y_pred.extend(predicted.cpu().numpy())
        y_true.extend(labels.cpu().numpy())

print("Evaluation Metrics for LSTM")
print(f"Accuracy: {accuracy_score(y_true, y_pred):.4f}")
print(f"Precision: {precision_score(y_true, y_pred, average='weighted'):.4f}")
print(f"Recall: {recall_score(y_true, y_pred, average='weighted'):.4f}")
print(f"F1 Score: {f1_score(y_true, y_pred, average='weighted'):.4f}")
print(classification_report(y_true, y_pred))
print("-" * 50)

# Define a reduced parameter grid for SVM
param_grid = {
    'C': [0.1, 1, 10],  # Reduced values
    'kernel': ['linear', 'rbf'],  # Exclude 'poly' to reduce combinations
    'gamma': ['scale', 'auto']  # Only relevant for 'rbf' kernel
}

# Initialize the GridSearchCV object with a reduced parameter grid
grid_search = GridSearchCV(SVC(probability=True), param_grid, cv=3, scoring='accuracy', verbose=2, n_jobs=-1)

# Fit the GridSearchCV object
print("Starting hyperparameter tuning for SVM...")
grid_search.fit(X_train_small, y_train_small)

# Get the best parameters and best score
best_params = grid_search.best_params_
best_score = grid_search.best_score_

print(f"Best parameters found: {best_params}")
print(f"Best cross-validation accuracy: {best_score:.4f}")

# Train the SVM model with the best parameters
print("Training SVM model with best parameters...")
best_svm_model = SVC(probability=True, **best_params)
best_svm_model.fit(X_train_small, y_train_small)

# Perform cross-validation
print("Performing cross-validation...")
cv_scores = cross_val_score(best_svm_model, X_train_small, y_train_small, cv=5, scoring='accuracy')

# Display cross-validation results
print(f"Cross-validation scores: {cv_scores}")
print(f"Mean cross-validation score: {cv_scores.mean():.4f}")
print(f"Standard deviation of cross-validation score: {cv_scores.std():.4f}")


# Evaluate the tuned model on the test set
print("Tuned Support Vector Machine Model")
svm_pred_best = best_svm_model.predict(X_test_small)
print(f"Accuracy: {accuracy_score(y_test_small, svm_pred_best):.4f}")
print(f"Precision: {precision_score(y_test_small, svm_pred_best, average='weighted'):.4f}")
print(f"Recall: {recall_score(y_test_small, svm_pred_best, average='weighted'):.4f}")
print(f"F1 Score: {f1_score(y_test_small, svm_pred_best, average='weighted'):.4f}")
print(classification_report(y_test_small, svm_pred_best))
print("-" * 50)

# Confusion Matrix
print("Confusion Matrix:")
conf_matrix = confusion_matrix(y_test_small, svm_pred_best)
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=label_encoder.classes_, yticklabels=label_encoder.classes_)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.show()

# ROC-AUC Curve
print("ROC-AUC Curve:")
y_test_bin = label_binarize(y_test_small, classes=[0, 1, 2])
svm_pred_prob_best = best_svm_model.predict_proba(X_test_small)
fpr = {}
tpr = {}
roc_auc = {}
for i in range(len(label_encoder.classes_)):
    fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], svm_pred_prob_best[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

# Plot ROC-AUC for each class
plt.figure()
colors = ['blue', 'red', 'green']
for i, color in zip(range(len(label_encoder.classes_)), colors):
    plt.plot(fpr[i], tpr[i], color=color, lw=2, label=f'ROC curve of class {label_encoder.classes_[i]} (area = {roc_auc[i]:0.2f})')
plt.plot([0, 1], [0, 1], 'k--', lw=2)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc='lower right')
plt.show()

# Precision-Recall Curve
print("Precision-Recall Curve:")
precision = {}
recall = {}
for i in range(len(label_encoder.classes_)):
    precision[i], recall[i], _ = precision_recall_curve(y_test_bin[:, i], svm_pred_prob_best[:, i])

# Plot Precision-Recall for each class
plt.figure()
for i, color in zip(range(len(label_encoder.classes_)), colors):
    plt.plot(recall[i], precision[i], color=color, lw=2, label=f'Precision-Recall curve of class {label_encoder.classes_[i]}')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision-Recall Curve')
plt.legend(loc='lower left')
plt.show()

# Feature Importance for Linear SVM
print("Feature Importance for Linear SVM:")
best_svm_linear = SVC(probability=True, kernel='linear', C=best_params['C'], gamma=best_params['gamma'])
best_svm_linear.fit(X_train_small, y_train_small)

# Get the feature importance (coefficients)
feature_importance = best_svm_linear.coef_.flatten()
feature_names = tfidf_vectorizer.get_feature_names_out()

# Ensure the lengths of feature_names and feature_importance match
if len(feature_names) == len(feature_importance):
    # Create a DataFrame to hold feature importance
    feature_importance_df = pd.DataFrame({
        'feature': feature_names,
        'importance': feature_importance
    })

    # Sort the DataFrame by importance
    feature_importance_df = feature_importance_df.sort_values(by='importance', ascending=False)

    # Display the top 10 features
    print("Top 10 positive features:")
    print(feature_importance_df.head(10))

    print("Top 10 negative features:")
    print(feature_importance_df.tail(10))

    # Plot the top 20 positive and negative features
    plt.figure(figsize=(10, 8))
    top_features = pd.concat([feature_importance_df.head(10), feature_importance_df.tail(10)])
    sns.barplot(x='importance', y='feature', data=top_features)
    plt.title('Top 10 Positive and Negative Features')
    plt.show()
else:
    print("Error: Mismatch in lengths of feature names and feature importance arrays.")

# Using LIME for Model Interpretability
print("Model Interpretability with LIME:")
explainer = lime.lime_tabular.LimeTabularExplainer(
    training_data=X_train_small,
    feature_names=tfidf_vectorizer.get_feature_names_out(),
    class_names=label_encoder.classes_,
    mode='classification'
)

# Choose an instance to explain
i = 0  # Index of the instance to explain
instance = X_test_small[i]

# Get the model's prediction for the instance
prediction = best_svm_model.predict(instance.reshape(1, -1))[0]
print(f"Model prediction: {label_encoder.inverse_transform([prediction])[0]}")

# Explain the prediction
explanation = explainer.explain_instance(instance, best_svm_model.predict_proba, num_features=10)

# Display the explanation
explanation.show_in_notebook(show_all=False)
print(explanation.as_list())

